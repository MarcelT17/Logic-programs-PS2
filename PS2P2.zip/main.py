lastname = input("Enter last name:")
hours = int(input("Enter hours:"))
payrate = int(input("pay rate:"))

grosspay = int(hours * payrate)

print(lastname," your gross pay is: $",grosspay)