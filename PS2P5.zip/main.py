price = int(input("Enter price of the item:"))
discount = float(input("Enter discount for this item"))

discount = float(discount / price) * 100
price = price - discount

print("the discounted price is:",price,"and the discount is",discount)