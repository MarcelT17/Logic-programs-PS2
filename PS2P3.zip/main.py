length = float(input("Enter length of rectangle:"))
width = float(input("Enter width of rectangle:"))

area = float(length * width)
circumference = float(2 * length + 2 * width)

print("area of rectangle is")
print(Circumference of rectangle is")