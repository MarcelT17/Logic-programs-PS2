quantity = float(input("Enter the quantity:"))
priceperunit = float(input("Enter price per unit:"))
computerextendedprice = float(quantity * priceperunit)

print("The extended price is:$",computerextendedprice)