lastname = input("Enter your last name:")
credits = int(input("Enter credits:"))

percredit = 250
labfee = 100

tuitionfee = (percredit * credits) + labfee

print(lastname," your tuition fee is:",tuitionfee)
